# ClosetIQ — real product catalog

Upload `index.html` and `products.json` into the root of your GitHub Pages repository. Enable Settings → Pages → Deploy from branch → main → root. No build or API key needed.

The catalog contains 19 Amazon India listings from an Apify export dated 2026-11-22. Prices and stock are snapshots; click through to Amazon for current information. Recommendations use deterministic wardrobe category, color, style and outfit compatibility rules. Image uploads are manually tagged, not AI-analyzed.

For new products, update `products.json` with the same schema. This is a hackathon prototype; review retailer content usage requirements before public distribution.
